package kau.edu.quran;

public class Sourah {
    public String name,id;

}
